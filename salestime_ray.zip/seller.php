<?php
include("./config.php");
session_start();
if (!isset($_SESSION["acc"]) || empty($_SESSION["acc"]) || !isset($_SESSION['loggedin'])) {
    header("Location: ./home.php");
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.5.0.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@300&display=swap" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/10094612fa.js"></script>
    <title>賣場管理</title>
</head>

<body>
    <header>
        <div class="container">
            <div class="row justify-content-end">
                <div class="col-auto align-self-end">
                    <a href="userlove.php">
                        <i class="fa-solid fa-heart icon_head"></i>
                    </a>
                    <a href="warecar.php">
                        <i class="fa-solid fa-cart-shopping icon_head"></i>
                    </a>
                    <a href="#">
                        <i class="fa-solid fa-comment-dots icon_head"></i>
                    </a>
                    <a href="member.php">
                        <i class="fa-solid fa-user icon_head" id="showID"></i>
                    </a>
                    <a href="./logout.php"><i class="fa fa-sign-out"></i></a>
                </div>
            </div>
            <a class="navbar-brand" href="home.php">
                <img id="logo" src="img/logo_4.png">
            </a>

            <div class="row">
                <nav class="navbar navbar-expand-lg navbar-light bg-light">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse col-auto" id="navbarSupportedContent">
                            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                <li class="nav-item">
                                    <a class="nav-link active" aria-current="page">
                                        <div>
                                            <select name="select_box" class="form-select text-left" id="select_box">
                                                <option>選擇遊戲</option>
                                                <option>新楓之谷</option>
                                                <option>APEX</option>
                                                <option>英雄聯盟</option>
                                            </select>
                                        </div>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link">
                                        <select class="form-select text-left">
                                            <option>選擇伺服器</option>
                                            <option>雪吉拉</option>
                                            <option>菇菇寶貝</option>
                                            <option>三眼章魚</option>
                                        </select>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link">
                                        <input id="search_width" class="search-txt text-left" type="text" name="" placeholder="請輸入道具名稱">
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a type="button" class="btn-head" href="index.php">
                                        <p>搜尋</p>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </header>
    <section>
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-3" id="menu-left">
                    <div class="accordion" id="accordionExample">
                        <div class="card">
                            <div class="card-header" id="headingOne">
                                <h2 class="mb-0">
                                    <a class="btn btn-link" data-toggle="collapse" href="#collapseOne" role="button" aria-expanded="false" aria-controls="collapseOne">
                                        <h5>我是買家</h5>
                                    </a>
                                </h2>
                            </div>

                            <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                                <div class="card-body">
                                    <a href="warecar.php">
                                        <p>我的專屬</p>
                                    </a>
                                    <a href="warecar.php">
                                        <p>我的訂單</p>
                                    </a>
                                    <a href="warecar.php">
                                        <p>折價券</p>
                                    </a>
                                    <a href="warecar.php">
                                        <p>收購中的商品</p>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="headingTwo">
                                <h2 class="mb-0">
                                    <a class="btn btn-link" data-toggle="collapse" href="#collapseTwo" role="button" aria-expanded="false" aria-controls="collapseTwo">
                                        <h5>我是賣家</h5>
                                    </a>
                                </h2>
                            </div>
                            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                                <div class="card-body">
                                    <a href="warecar.php">
                                        <p>我的專屬</p>
                                    </a>
                                    <a href="warecar.php">
                                        <p>我的訂單</p>
                                    </a>
                                    <a href="warecar.php">
                                        <p>折價券</p>
                                    </a>
                                    <a href="warecar.php">
                                        <p>收購中的商品</p>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="headingThree">
                                <h2 class="mb-0">
                                    <a class="btn btn-link" data-toggle="collapse" href="#collapseThree" role="button" aria-expanded="false" aria-controls="collapseThree">
                                        <h5>會員資料</h5>
                                    </a>
                                </h2>
                            </div>
                            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                                <div class="card-body">
                                    <a href="self_Info.html">
                                        <p>修改會員資料</p>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <table class="table table-hover">
                        <h2><strong>商品清單</strong></h2>
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">編號</th>
                                <th scope="col">商品名稱</th>
                                <th scope="col">商品描述</th>
                                <th scope="col">價格</th>
                                <th scope="col">庫存</th>
                                <th scope="col">上架時間</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $sid = $_SESSION["acc"];
                            $sql = "SELECT * FROM `products`  WHERE `sid` = '$sid'";
                            $i = 1;
                            $result = mysqli_query($link, $sql);
                            while ($row = mysqli_fetch_assoc($result)) {
                                $key = $row["pid"];
                                echo
                                "<tr>" .
                                    "<td></td>" .
                                    "<td>#" . $row["pid"] . "</td>" .
                                    "<td name='pname'>" . $row["pname"] . "</td>" .
                                    "<td name='pdescribe'>" . $row["pdescribe"] . "</td>" .
                                    "<td name='price'>" . $row["price"] . "</td>" .
                                    "<td name='stock'>" . $row["stock"] . "</td>" .
                                    "<td name='uploadtime'>" . $row["uploadtime"] . "</td>" .
                                    "<td name='update'>" . "<a name='' id='' class='btn btn-warning' href='./self_Product.php?key=$key' role='button'>修改</a>" . "</td>" .
                                    "</tr>" .
                                    $i++;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </section>
</body>

</html>