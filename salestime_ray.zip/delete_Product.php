<?php
include("./check_session.php");
include("./config.php");

if ($_POST) {
    $id = $_POST["pid"];

    $response = array("status", "msg");
    $success_msg = "刪除成功！";
    $failed_msg = "刪除失敗，請再次嘗試";

    $sql = "DELETE FROM `products` WHERE `pid`='$id'";
    $result = mysqli_query($link, $sql);

    if (mysqli_affected_rows($link) > 0) {
        $response["status"] = 1;
        $response["msg"] = $success_msg;
    } else {
        $response["status"] = 0;
        $response["msg"] = $failed_msg;
    }
    echo json_encode($response);
}
