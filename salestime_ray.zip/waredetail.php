<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@300&display=swap" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/10094612fa.js"></script>
    <title>小賣時光－最懂你／妳的寶物交易網</title>
</head>
<body>
    <header>
        <div class="container">
          <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
              <a class="navbar-brand" href="home.php">
                  <img id="logo" src="img/logo_4.png">
              </a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
  
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page">
                        <div>
                            <select name="select_box" class="form-select text-left" id="select_box">
                                <option>選擇遊戲</option>
                                <option>新楓之谷</option>
                                <option>APEX</option>
                                <option>英雄聯盟</option>
                            </select>
                        </div>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link">
                        <select class="form-select text-left">
                            <option>選擇伺服器</option>
                            <option>雪吉拉</option>
                            <option>菇菇寶貝</option>
                            <option>三眼章魚</option>
                        </select>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link">
                        <input id="search_width" class="search-txt text-left" type="text" name="" placeholder="請輸入道具名稱">
                    </a>
                  </li>
                  <li class="nav-item">
                    <a type="button" class="btn-head" href="index.php"><p>搜尋</p></a>
                  </li>
                </ul>
                <ul class="navbar-nav me-auto mb-2 mb-lg-0" id="icon_start">
                    <li class="d-flex nav-item icon_head">
                        <a href="userlove.php">
                            <i class="fa-solid fa-heart icon_head"></i>
                        </a>
                        <a href="member.php">
                          <i class="fa-solid fa-user icon_head"></i>
                        </a>
                        <a href="warecar.php">
                          <i class="fa-solid fa-cart-shopping icon_head"></i>
                        </a>
                        <a href="#">
                            <i class="fa-solid fa-comment-dots icon_head"></i>
                        </a>
                    </li>
                </ul>
              </div>
            </div>
          </nav>
        </div>
    </header>

    <section id="detail-first">
        <div class="container">
            <div class="row">
                <div class="col-md-7  offset-md-1">
                    <h4 class="fw-bold">280等天使破壞者大ㄐㄐ</h4>
                    <hr>
                    <div class="container">
                        <div id="detail-first-point" class="row">
                            <div id="detail-img" class="col-md-4">
                                <img src="img/user/user1.jpg">
                            </div>
                            <div class="col-md-8">
                                <div id="detail-first-center" class="container">
                                    <div id="detail-first-price"  class="row justify-content-between">
                                        <div class="col-md-4">
                                            <h5 class="fw-bold">價格:200,000</h5>
                                        </div>
                                        <div class="col-md-4">
                                            <h5 class="fw-bold">人氣:1234</h5>
                                        </div>
                                    </div>
                                    <div id="detail-first" class="row">
                                        <div class="col-md-12">
                                            <p>遊戲伺服:新楓之谷/殺人鯨</p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <p>賣家服務:承諾於五小時內完成交易</p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <form id='myform' method='POST' action='#'>
                                                <label for="">購買數量: </label>
                                                <input type='button' value='-' class='qtyminus' field='quantity'>
                                                <input type='text' name='quantity' value='0' class='qty'>
                                                <input type='button' value='+' class='qtyplus' field='quantity'>
                                            </form>
                                            <p id="number">(庫存:1件)</p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <a type="button" class="detail-btn" href="#"><p>購買</p></a>
                                        </div>
                                        <div id="detail-first-userlove" class="col-md-4">
                                            <a href="#">
                                                <i class="fa-solid fa-heart">
                                                    追蹤這件商品
                                                </i>
                                            </a>
                                        </div>    
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="detail-seller" class="col-md-2 text-center">
                    <h5 class="fw-bold">賣家資料</h5>
                    <p>會員:No.1234567</p>
                    <p>狀態:上線中</p>
                    <hr>
                    <p>評價:100分</p>
                    <hr>
                    <a href="#"><p>查看賣家所有商品</p></a>
                </div>    
            </div>
            <hr>    
        </div>
    </section>


    <section>
        <div id="detail-second" class="container">
            <div class="row">
                <div class="col-md-12 offset-md-1">
                    <div id="detail-second-data-title" class="col-md-2 text-center">
                        <h4 class="fw-bold">商品詳細資訊</h4>
                    </div>
                </div>
            </div>
            <div id="detail-second-data" class="row">
                <div class="col-md-3 offset-md-1">
                    <h5>商品編號:123456789</h5>
                </div>
                <div class="col-md-3">
                    <h5>刊登時間:2022-05-07 12:00:00</h5>
                </div>
            </div>

            <div class="row">
                <div id="detail-second-img" class="col-md-12  text-center">
                    <img src="img/shop/test.png">
                </div>
                <div id="detail-second-text" class="col-md-12 offset-md-1 text-left">
                    <p>11年老字號</p>
                    <p>決不把你當盤子薛</p>
                    <p>價錢可談，20萬直購</p>
                </div>
            </div>
        </div>
        <hr>
    </section>


    <footer id="foot-one">
        <div class="container">
          <div class="row">
            <div class="col-md-3 text-center">
              <h5 class="fw-bold">新手上路</h5>
              <p><a href="#">免費註冊</a></p>
              <p><a href="#">交易流程</a></p>
              <p><a href="#">付款方式</a></p>
            </div>
            <div class="col-md-3 text-center">
              <h5 class="fw-bold">售後服務</h5>
              <p><a href="#">交易申訴</a></p>
              <p><a href="#">申請取消交易</a></p>
              <p><a href="#">提款相關</a></p>
            </div>
            <div class="col-md-3 text-center">
              <h5 class="fw-bold">客戶服務</h5>
              <p>客服電話：(02) 5579-8591</p>
              <p>服務時間：週一至週五10:00-21:00</p>
              <p>例行維護：每日4:30-5:00</p>
            </div>
            <div class="col-md-3 text-center">
              <h5 class="fw-bold">常用入口</h5>
              <p><a href="#">帳號切結書下載</a></p>
              <p><a href="#">留言諮詢</a></p>
              <p><a href="#">客服信箱</a></p>
            </div>
          </div>
        </div>
    </footer>
  
    <button type="button" class="btn btn-danger btn-floating btn-lg back-to-top" id="btn-back-to-top">
        <i class="fa-solid fa-arrow-up"></i>
    </button>
  
    <script src="js/test.js"></script>

</body>
</html>