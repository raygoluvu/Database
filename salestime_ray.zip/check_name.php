<?php
include("./config.php");

$name  = $_POST['name'];

$ret_arr =  array();

if($_POST){
    if($_POST['name'] == NULL){
        echo 1;
    }else{
        echo 0;
    }
}

?>