<?php
include("./config.php");

session_start();
$msg_empty = "login";
$res = array();

if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] == true && isset($_SESSION["acc"])){
      $acc = $_SESSION['acc'];
      $sql = "SELECT * FROM `users` WHERE `account` = '$acc' ;";
      $result = mysqli_query($link, $sql);
      $row = mysqli_fetch_assoc($result);
      $res["msg"] = $row["username"];
  }else{
    $res["msg"] = $msg_empty;
  }
echo json_encode($res);
