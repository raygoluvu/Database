<?php

session_start();

if(($acc = $_SESSION['acc']) == NULL){
    echo "<script>alert('請先登入');</script>";
     
    exit;
}else{
    $acc = $_SESSION['acc'];
    echo "<h1>您好，".$acc."</h1>";
    echo "<a href='logout.php'>登出</a>";
}


?>