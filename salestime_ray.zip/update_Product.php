<?php
include("./check_session.php");
include("./config.php");

if ($_POST) {
    $pid = $_POST["pid"];
    $pname = $_POST["pname"];
    $price = $_POST["price"];
    $pdescribe = $_POST["pdescribe"];
    $stock = $_POST["stock"];

    $response = array("status", "msg");
    $success_msg = "更新成功！";
    $failed_msg = "更新失敗，請再次嘗試";


    $sql = "UPDATE `products` SET `pname`='$pname', `price`='$price',`pdescribe`='$pdescribe',`stock`='$stock' WHERE `pid` = '$pid'";
    $result = mysqli_query($link, $sql);
    if (mysqli_affected_rows($link) > 0) {
        $response["status"] = 1;
        $response["msg"] = $success_msg;
    } else {
        $response["status"] = 0;
        $response["msg"] = $failed_msg;
    }
    echo json_encode($response);
}
