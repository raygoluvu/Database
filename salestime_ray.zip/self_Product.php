<?php
include("./check_session.php");
include("./config.php");
if ($_GET) {
    $key = $_GET["key"];
    $sql = "SELECT * FROM `products` WHERE `pid`='$key'";
    $result = mysqli_query($link, $sql);
    $info = mysqli_fetch_assoc($result);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif+TC:wght@600&display=swap" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.0.min.js"></script>
    <script type="text/javascript" src="./js/jquery.validate.js"></script>
    <script type="text/javascript" src="./js/messages_zh_TW.js"></script>
    <script type="text/javascript" src="./js/additional-methods.js"></script>
    <link rel="icon" href="愛之味.ico">
    <title>更新商品</title>
</head>

<body>
    <div class="container m-5">
        <div class="col-auto alert alert-primary" role="alert">
            <strong>使用者資料</strong><br>
            <strong>User: <?= $_SESSION['acc'] ?></strong>
        </div>

        <div class="row justify-content-center" id="content">
            <div class="col-10">
                <form id="info" autocomplete="off">
                    <br>
                    <input type="text" class="form-control" name="pid" aria-describedby="idhelpId" style="display: none;" value="<?= $info["pid"] ?>">
                    <div class="form-group">
                        <label for="pname" class="form-label">商品名稱</label>
                        <input type="text" class="form-control" name="pname" id="pname" aria-describedby="pnhelpId" placeholder="" value="<?= $info["pname"] ?>">
                        <small id="pnhelpId" class="form-text text-muted"></small>
                    </div>
                    <div class="form-group">
                        <label for="category" class="form-label">分類</label>
                        <input type="text" class="form-control" name="category" id="category" aria-describedby="categoryhelpId" placeholder="" value="<?= $info["category"] ?>">
                        <small id="categoryhelpId" class="form-text text-muted"></small>
                    </div>
                    <div class="form-group">
                        <label for="price" class="form-label">商品價格</label>
                        <input type="text" class="form-control" name="price" id="price" aria-describedby="category2helpId" placeholder="" value="<?= $info["price"] ?>">
                        <small id="category2helpId" class="form-text text-muted"></small>
                    </div>
                    <div class="form-group">
                        <label for="pdescribe" class="form-label">商品描述</label>
                        <input type="text" class="form-control" name="pdescribe" id="pdescribe" aria-describedby="pdescribehelpId" placeholder="" value="<?= $info["pdescribe"] ?>">
                        <small id="pdescribehelpId" class="form-text text-muted"></small>
                    </div>
                    <div class="form-group">
                        <label for="stock" class="form-label">庫存</label>
                        <input type="text" class="form-control" name="stock" id="stock" aria-describedby="stockhelpId" placeholder="" value="<?= $info["stock"] ?>">
                        <small id="stockhelpId" class="form-text text-muted"></small>
                    </div>
                    <div class="form-group pt-3">
                        <button id="update" type="button" class="btn col-12" style="background-color:#ff4e00;color: white" value="update">確定修改
                        </button>
                    </div>
                </form>
            </div>
            <div class="d-grid gap-5 col-6 mx-auto m-3">
                <button type="button" class="btn btn-danger col-12" data-bs-toggle="modal" data-bs-target="#staticBackdrop">刪除商品</button>
                <!-- Modal -->
                <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">提醒</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                請確認是否真的刪除商品，一但刪除即無法復原。
                            </div>
                            <div class="modal-footer">
                                <form id="delform">
                                    <input type="text" class="form-control" name="pid" aria-describedby="idhelpId" style="display: none;" value="<?= $info["pid"] ?>">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                                    <button type="button" class="btn btn-danger" id="del">確定</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

<script>
    $(document).ready(
        $("#info").validate({
            keyup: true,
            lang: 'zh_TW',
            rules: {
                pname: {
                    required: true,
                },
                category: {
                    required: true,
                },
                price: {
                    required: true,
                },
            },
            errorElement: 'div',
            errorClass: "form-text mx-2 hint_text",
            errorPlacement: function(error, element) {
                error.appendTo(element.parent())
                error.css("color", "red");
            }
        })
    )

    $("#update").on("click", function() {
        $.ajax({
            type: "POST",
            url: "./update_Product.php",
            data: $("#info").serialize(),
            dataType: "JSON",
            success: function(response) {
                if (response["status"] == 1) {
                    alert(response["msg"]);
                    window.location.href = "./seller.php"
                } else {
                    alert(response["msg"] + "error");
                    window.location.reload(true);
                }
            }
        });
    })

    $("#del").on("click", function() {
        $.ajax({
            type: "POST",
            url: "./delete_Product.php",
            dataType: "JSON",
            data: $("#delform").serialize(),
            success: function(response) {
                if (response["status"] == 1) {
                    alert(response["msg"]);
                    window.location.href = "./seller.php";
                } else {
                    alert(response["msg"]);
                    window.location.reload(true);
                }
            }
        });
    })
</script>