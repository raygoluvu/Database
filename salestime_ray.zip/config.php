<?php
$db = "salestime";
$link = mysqli_connect("localhost", "root", "", $db);
if (!$link) {
    die("Connection failed: " . mysqli_connect_error());
}
?>