<?php

include("./config.php");

$pid = $_POST['pid'];
$sql_check_pid = "SELECT * FROM `users` WHERE `id` = '$pid'";

if ($_POST) {
    $result = mysqli_query($link, $sql_check_pid);
    $nums = mysqli_num_rows($result);
    if ($nums > 0) {
        echo 1;
    }
    if ($nums == 0) {
        echo 0;
    }
}
