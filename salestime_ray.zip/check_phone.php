<?php

include("./config.php");

$phone = $_POST['phone'];
$sql_check_phone = "SELECT * FROM `users` WHERE `phone` = '$phone'";

if ($_POST) {
    $result = mysqli_query($link, $sql_check_phone);
    $nums = mysqli_num_rows($result);
    if ($nums > 0) {
        echo 1;
    }
    if ($nums == 0) {
        echo 0;
    }
}
