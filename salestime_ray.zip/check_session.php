<?php

session_start();

if (isset($_SESSION["loggedin"]) && isset($_SESSION["acc"]) && !empty($_SESSION["acc"])) {
} else {
    header("Location: ./home.php");
    exit;
}
