<?php

include("./config.php");
session_start();
$acc = $_SESSION["acc"];

$sql = "SELECT * FROM `users` WHERE `account` = '$acc'";
$result = mysqli_query($link, $sql);
$info = mysqli_fetch_assoc($result);
echo json_encode($info);
