<?php
include("./config.php");

$uname  = $_POST['username'];
$sql_check_n = "SELECT * FROM `users` WHERE `username` = '$uname'";
$acc = $_POST['acc'];
$sql_check_acc = "SELECT * FROM `users` WHERE `account` = '$acc'";

$ret_arr =  array();

if ($_POST) {
    $num1 = mysqli_num_rows(mysqli_query($link, $sql_check_n));
    $num2 = mysqli_num_rows(mysqli_query($link, $sql_check_acc));
    $num3 = $_POST['pwd'] != $_POST['pwd_check'];
    if ($_POST['username'] == NULL or $_POST['acc'] == NULL or $_POST['pwd'] == NULL or $_POST['pwd_check'] == NULL) {
        $status = 0;
        $text = "請先完成登入資料"; 
    }elseif($num1 == 1){
        $status = 1;
        $text = "使用者名稱已被使用或輸入錯誤";
    } elseif($num2 == 1){
        $status = 2;
        $text = "帳號已被使用或輸入錯誤";
    }elseif($num3){
        $status = 3;
        $text = "請重複確認密碼";
    }else {
        $status = 4;
        $text = "請繼續填寫個人資料";
    }
    $ret_arr[] = array("status" => $status, "text" => $text);
    echo json_encode($ret_arr);
}
