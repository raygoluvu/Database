<?php
include("./config.php");

session_start();
$acc = $_SESSION['acc'];

if(!empty($acc)){
    $sql = "DELETE  FROM `users` WHERE `account`='$acc'";
    $result = mysqli_query($link, $sql);
    $response = array("status", "msg");
    $success_msg = "成功刪除帳號";
    $failed_msg = "刪除失敗";

    if(mysqli_affected_rows($link)>0){
        $response["status"]=1;
        $response["msg"]=$success_msg;
        session_destroy();
        echo json_encode($response);
    }
    else{
        $response["status"]=0;
        $response["msg"]=$failed_msg;
        echo json_encode($response);
    }
}else{
    header("Location: ./login.php/");
}
?>