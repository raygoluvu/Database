<?php
include("./config.php");

$token = trim($_GET["token"]);
$sql = "SELECT * FROM `authorization` NATURAL JOIN `users` WHERE `token` = '$token'";
$result = mysqli_query($link, $sql);
print_r($result);
if (mysqli_num_rows($result) > 0) {
    $info = mysqli_fetch_assoc($result);
    $id = $info["id"];
    echo "id=" . $id;
    $sql = "UPDATE `users` SET `status`='1' WHERE `id`='$id'";

    $result = mysqli_query($link, $sql);
    if (mysqli_affected_rows($link) == 1) {
?>
        <script>
            alert("信箱驗證成功，請重新登入");
            window.location.href = "./login.php";
        </script>
    <?php
    } else {
    ?>
        <script>
            alert("驗證失敗，請修改為正確信箱");
            window.location.href = "./login.php";
        </script>
<?php
    }
}
