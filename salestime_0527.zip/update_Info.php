<?php

include("./config.php");

if ($_POST) {
    session_start();
    $acc = $_POST["account"];
    $pwd = $_POST["pwd"];
    $un = $_POST["username"];
    $n = $_POST["name"];
    $p = $_POST["phone"];
    $m = $_POST["mail"];

    $response = array("status", "msg");
    $msg_success = "修改成功，請重新登入";
    $msg_failed = "修改失敗";

    $sql = "UPDATE `users` SET `password`='$pwd',`username`='$un',`name`='$n',`phone`='$p',`mail`='$m' WHERE `account`=  '$acc'";
    $result = mysqli_query($link, $sql);
    if (mysqli_affected_rows($link) > 0) {
        $response["status"] = 1;
        $response["msg"] = $msg_success;
        session_destroy();
        echo json_encode($response);
    } else {
        $response["status"] = 0;
        $response["msg"] = $msg_failed;
        echo json_encode($response);
    }
}
