<?php
include("./check_session.php");
include("./config.php");


if ($_POST) {
    $gname = $_POST['gname'];
    $json = [];
    $sql = "SELECT `sid`, `sname` FROM `servers` WHERE `gname` = '$gname'";
    $result = mysqli_query($link, $sql);
    while ($row = mysqli_fetch_assoc($result)) {
        $json[$row['sid']] = $row["sname"];
    }
    echo json_encode($json);
} else {
    // header("Location: ./home.php");
}
