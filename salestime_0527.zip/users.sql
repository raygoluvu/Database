-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 2022-05-07 08:18:13
-- 伺服器版本： 10.4.22-MariaDB
-- PHP 版本： 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫: `salestime`
--

-- --------------------------------------------------------

--
-- 資料表結構 `users`
--

CREATE TABLE `users` (
  `account` varchar(10) NOT NULL,
  `password` varchar(15) NOT NULL,
  `username` varchar(10) NOT NULL,
  `name` varchar(10) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `mail` varchar(30) NOT NULL,
  `id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 傾印資料表的資料 `users`
--

INSERT INTO `users` (`account`, `password`, `username`, `name`, `phone`, `mail`, `id`) VALUES
('a', 'a', 'a', 'a', '1', 'a', 'a'),
('aa', 'aa', 'aa', 'aa', '123', 'aa', 'aa'),
('aas', 'aas', 'aas', 'rre', '221', 'qwe', 'e123'),
('f', 'aa', 'f', 'qwe', '3321', '123', 'wer'),
('fd', 'fd', 'fd', 'fd', '2234', 'fd', 'fd'),
('g', 'g', 'g', 'g', '4', 'g', 'g'),
('girl', 'punch', 'girl', 'girl', '0987654321', 'a@gmail.com', 'E123456789'),
('s', 's', 's', 's', '0', 's', 's'),
('w', 'w', 'w', 'w', '3', 'w', 'w'),
('z', 'z', 'z', 'z', '1234', 'z', 'z');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`account`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `mail` (`mail`),
  ADD UNIQUE KEY `id` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
