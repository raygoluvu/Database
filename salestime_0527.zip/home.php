<!DOCTYPE html>
<?php
session_start();
include("config.php");
?>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://code.jquery.com/jquery-3.5.0.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@300&display=swap" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/10094612fa.js"></script>
  <title>小賣時光－最懂你／妳的寶物交易網</title>
</head>

<style>
  header {
    background-color: #E0EDC5;
  }
</style>

<body>
  <header>
    <div class="container">
      <div id="" class="row justify-content-end">
        <div class="col-auto align-self-end">
          <a href="userlove.php">
            <i class="fa-solid fa-heart icon_head"></i>
          </a>
          <a href="warecar.php">
            <i class="fa-solid fa-cart-shopping icon_head"></i>
          </a>
          <a href="#">
            <i class="fa-solid fa-comment-dots icon_head"></i>
          </a>
          <a href="member.php">
            <i class="fa-solid fa-user icon_head" id="showID"></i>
          </a>
          <a id="logout" href="./logout.php"><i class="fa fa-sign-out"></i></a>
        </div>
      </div>
      <a class="navbar-brand" href="home.php">
        <img id="logo" src="img/logo_4.png">
      </a>

      <div class="row">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse col-auto" id="navbarSupportedContent">
              <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page">
                    <div>
                      <select name="select_box" class="form-select text-left" id="select_box">
                        <option>選擇遊戲</option>
                        <option>新楓之谷</option>
                        <option>APEX</option>
                        <option>英雄聯盟</option>
                      </select>
                    </div>
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link">
                    <select class="form-select text-left">
                      <option>選擇伺服器</option>
                      <option>雪吉拉</option>
                      <option>菇菇寶貝</option>
                      <option>三眼章魚</option>
                    </select>
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link">
                    <input id="search_width" class="search-txt text-left" type="text" name="" placeholder="請輸入道具名稱">
                  </a>
                </li>
                <li class="nav-item">
                  <a type="button" class="btn-head" href="index.php">
                    <p>搜尋</p>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </div>
    </div>

  </header>

  <section id="first">
    <div class="container">
      <div class="row container-fluid justify-content-center">
        <div class="col-md">
          <div id="ad" class="text-center">
            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src="img/logo_3.png" class="d-block" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="img/logo_3.png" class="d-block" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="img/logo_3.png" class="d-block" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="img/logo_3.png" class="d-block" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="img/logo_3.png" class="d-block" alt="...">
                </div>
              </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>
          </div>
        </div>
        <!--  -->
      </div>
    </div>
  </section>

  <hr>

  <section id="second">
    <div class="container">
      <div class="row">
        <div id="game_2" class="col-md-12 text-center">
          <ul class="pagination">
            <li class="page-item ">
              <a class="page-link red" href="#">
                <h3>線上遊戲</h3>
              </a>
            </li>
            <li class="page-item">
              <a class="page-link" href="#">
                <h3>手機遊戲</h3>
              </a>
            </li>
            <li class="page-item">
              <a class="page-link" href="#">
                <h3>網頁遊戲</h3>
              </a>
            </li>
            <li class="page-item">
              <a class="page-link" href="#">
                <h3>Steam區</h3>
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div class="row">
        <div id="new" class="col-md-12 text-center">
          <ul class="pagination">
            <li class="page-item ">
              <a class=" page-link blue" href="#">
                <h3>熱門商品</h3>
              </a>
            </li>
            <li class="page-item">
              <a class="page-link" href="#">
                <h3>最新發布</h3>
              </a>
            </li>
            <li class="page-item">
              <a class="page-link" href="#">
                <h3>其他人在看</h3>
              </a>
            </li>
          </ul>
        </div>
      </div>

      <!-- css -->
      <style>
        table tr[data-href] {
          cursor: pointer;
        }
      </style>

      <div class="row justify-content-center">
        <div class="col-10">
          <div id="table">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th scope="col"></th>
                  <th scope="col" class="text-center" id="table_title">商品名稱</th>
                  <th scope="col" class="text-center" id="table_price">價格</th>
                  <th scope="col" class="text-center" id="table_date">商品描述</th>
                  <th scope="col" class="text-center" id="table_famus">庫存</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $sql_fetch = "SELECT * FROM `products` LIMIT 10";
                $p_result = mysqli_query($link, $sql_fetch);
                $count = 1;
                // 記得加上數標覆蓋出現手指的css
                while ($row = mysqli_fetch_assoc($p_result)) {
                  $pid = $row["pid"];
                  echo "<tr href = './waredetail.php?pid=$pid'>";
                  echo "<td scope='col' class='text-center'>" . $count . "</td>";
                  echo "<td scope='col' class='text-center'>" . $row['pname']  . "</td>";
                  echo "<td scope='col' class='text-center'>" . $row['price'] . "</td>";
                  echo "<td scope='col' class='text-center'>" . $row['pdescribe'] . "</td>";
                  echo "<td scope='col' class='text-center'>" . $row['stock'] . "</td>";
                  echo "</tr>";
                  $count++;
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
  </section>

  <section id="third">
    <div class="row container-fluid">
      <div id="title" class="col-md-12 text-center">
        <img src="img/logo_1.png">
      </div>
    </div>
  </section>

  <footer id="foot-one">
    <div class="container">
      <div class="row">
        <div class="col-md-3 text-center">
          <h5 class="fw-bold">新手上路</h5>
          <p><a href="#">免費註冊</a></p>
          <p><a href="#">交易流程</a></p>
          <p><a href="#">付款方式</a></p>
        </div>
        <div class="col-md-3 text-center">
          <h5 class="fw-bold">售後服務</h5>
          <p><a href="#">交易申訴</a></p>
          <p><a href="#">申請取消交易</a></p>
          <p><a href="#">提款相關</a></p>
        </div>
        <div class="col-md-3 text-center">
          <h5 class="fw-bold">客戶服務</h5>
          <p>客服電話：(02) 5579-8591</p>
          <p>服務時間：週一至週五10:00-21:00</p>
          <p>例行維護：每日4:30-5:00</p>
        </div>
        <div class="col-md-3 text-center">
          <h5 class="fw-bold">常用入口</h5>
          <p><a href="#">帳號切結書下載</a></p>
          <p><a href="#">留言諮詢</a></p>
          <p><a href="#">客服信箱</a></p>
        </div>
      </div>
    </div>
  </footer>

  <button type="button" class="btn btn-danger btn-floating btn-lg back-to-top" id="btn-back-to-top">
    <i class="fa-solid fa-arrow-up"></i>
  </button>

  <!-- <script src="js/test.js"></script> -->
</body>

</html>

<script>
  $(document).ready(
    function() {
      $.ajax({
        url: "./getUser.php",
        type: "POST",
        dataType: "JSON",
        success: function(response) {
          $("#showID").append(response["msg"]);
        }
      })
    },
    $('table tr').click(function() {
      window.location = $(this).attr('href');
      return false;
    }),
    $("#logout").click(function() {
      alert("帳號已登出");
      window.location.href = "./home.php";
    })
  )
</script>