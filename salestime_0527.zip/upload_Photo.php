<?php
include("./config.php");
include("./check_session.php");
if ($_POST) {
    if (isset($_FILES['myfile'])) {
        $file_name = $_FILES['myfile']['name'];
        $file_tmp = $_FILES['myfile']['tmp_name'];
        $file_size = $_FILES['myfile']['size'];
        $file_error = $_FILES['myfile']['error'];

        $file_ext = explode('.', $file_name);
        $name = $file_ext[0];
        $ext = strtolower(end($file_ext)); // end(), equal to array[i];

        $pid = $_POST["pid"];
        $allowed = array("jpg", "png");
        if (in_array($ext, $allowed)) {     //確認格式是否正確
            if ($file_error === 0) {
                if ($file_size < 200000) {
                    $file_destination = "./img/test/" . $name . "_" . $pid . "." . $ext;
                    if (move_uploaded_file($file_tmp, $file_destination)) {
                        echo "<script>";
                        echo "console.log('檔案已上傳')";
                        echo "</script>";
                    } else {
                        if (file_exists($file_destination)) {
                            echo "檔案已存在";
                        }
                    }
                    $sql = "INSERT INTO `product_photos`(`src`, `pid`) VALUES ('$file_destination','$pid')";
                    $result = mysqli_query($link, $sql);
                    if (mysqli_affected_rows($link)) {
                        echo "<script>";
                        echo "alert('上傳成功')";
                        echo "</script>";
                        $sql = "SELECT * FROM `product_photos` WHERE `pid`='$pid'";
                        $ret = mysqli_query($link, $sql);
                        $photo = mysqli_fetch_assoc($ret);
                        $src = $photo["src"];
                        echo "<img src='$src' alt=''>";
                    } else {
                        echo "<script>";
                        echo "alert('上傳失敗')";
                        // echo "window.location.href='./seller.php'";
                        echo "</script>";
                    }
                }
            }
        }
    }
}
