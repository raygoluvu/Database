<?php
include("./config.php");
require "php/PHPMailer.php";
require "php/SMTP.php";
require "php/Exception.php";

use PHPMailer\PHPMailer\{PHPMailer, SMTP, Exception};

$mailer = new PHPMailer();
$mailer->isSMTP();
$mailer->Host = "smtp.gmail.com";
$mailer->SMTPAuth = "true";
$mailer->SMTPSecure = "tls";
$mailer->Port = "25";
$mailer->Username = "onlyfordb2022@gmail.com";
$mailer->Password = "onlyfordb";
$mailer->Subject = "小麥時光驗證信";
$mailer->setFrom("onlyfordb2022@gmail.com");
$mailer->isHTML(true);
$mailer->Body =
    "<h1>✨✨✨✨✨✨✨✨✨✨✨</h1>" .
    "<h1>✨🦔🦔🦔<strong style='color: green;'>小麥時光</strong>🦔🦔🦔✨</h1>" .
    "<h1>✨✨✨✨✨✨✨✨✨✨✨</h1>" .
    "<p>點擊下方連結或是 <a href='C:\xampp\htdocs\DB\salestime\mailAuthorize.php?token='>這裡</a> 開通帳號</p>" .
    "<a href='C:\xampp\htdocs\DB\salestime\mailAuthorize.php?token='>" . "</a>";
$mailer->addAddress("onlyfordb2022@gmail.com");
if ($mailer->send()) {
    echo "success";
} else {
    echo "filed";
}
