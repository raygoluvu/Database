<?php
include("./check_session.php");
include("./config.php");
if ($_GET) {
    $key = $_GET["key"];
    $sql = "SELECT * FROM `products` WHERE `pid`='$key'";
    $result = mysqli_query($link, $sql);
    $info = mysqli_fetch_assoc($result);
    $serverid = $info["serverid"];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif+TC:wght@600&display=swap" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    <script src='http://code.jquery.com/jquery.js'></script>
    <script type="text/javascript" src="./js/jquery.validate.js"></script>
    <script type="text/javascript" src="./js/messages_zh_TW.js"></script>
    <script type="text/javascript" src="./js/additional-methods.js"></script>
    <script src="js/uploadImages.js"></script>
    <link rel="icon" href="愛之味.ico">
    <title>更新商品</title>
</head>



<body>
    <div class="container m-5">
        <div class="col-auto alert alert-primary" role="alert">
            <strong>使用者資料</strong><br>
            <strong>User: <?= $_SESSION['acc'] ?></strong>
        </div>

        <div class="row justify-content-center" id="content">
            <div class="col-10">
                <form id="info" autocomplete="off" enctype="multipart/form-data">
                    <br>
                    <div class="form-group py-2">
                        <label for="gname">遊戲名稱</label>
                        <select class="form-select" aria-label="Default select example" name="gname">
                            <option>選擇遊戲</option>
                            <?php
                            $sql_fetch = "SELECT * FROM `games`";
                            $f_result = mysqli_query($link, $sql_fetch);
                            $result = mysqli_query($link, "SELECT `gname` FROM `servers` WHERE `sid`='$serverid'");
                            $selName = mysqli_fetch_assoc($result)["gname"];
                            while ($row = mysqli_fetch_assoc($f_result)) {
                                $v = $row['gname'];
                                if ($selName == $v) {
                                    echo "<option selected " . "value='$v'>";
                                    echo $v;
                                    echo "</option>";
                                } else {
                                    echo "<option " . "value='$v'>";
                                    echo $v;
                                    echo "</option>";
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group py-2">
                        <label for="server">伺服器</label>
                        <select class="form-select" aria-label="Default select example" name="server" id="server">
                            <option selected>請先選擇遊戲</option>
                        </select>
                    </div>
                    <input type="text" class="form-control" name="pid" aria-describedby="idhelpId" style="display: none;" value="<?= $info["pid"] ?>">
                    <div class="form-group">
                        <label for="pname" class="form-label">商品名稱</label>
                        <input type="text" class="form-control" name="pname" id="pname" aria-describedby="pnhelpId" placeholder="" value="<?= $info["pname"] ?>">
                        <small id="pnhelpId" class="form-text text-muted"></small>
                    </div>
                    <div class="form-group">
                        <label for="price" class="form-label">商品價格</label>
                        <input type="text" class="form-control" name="price" id="price" aria-describedby="category2helpId" placeholder="" value="<?= $info["price"] ?>">
                        <small id="category2helpId" class="form-text text-muted"></small>
                    </div>
                    <div class="form-group">
                        <label for="pdescribe" class="form-label">商品描述</label>
                        <textarea type="text" class="form-control" name="pdescribe" id="pdescribe" aria-describedby="pdescribehelpId" placeholder="" value="<?= $info["pdescribe"] ?>"><?= $info["pdescribe"] ?></textarea>
                        <small id="pdescribehelpId" class="form-text text-muted"></small>
                    </div>
                    <div class="form-group">
                        <label for="stock" class="form-label">庫存</label>
                        <input type="text" class="form-control" name="stock" id="stock" aria-describedby="stockhelpId" placeholder="" value="<?= $info["stock"] ?>">
                        <small id="stockhelpId" class="form-text text-muted"></small>
                    </div>
                    <div class="form-group">
                        <label for="myfile" class="form-label">上傳相片</label>
                        <br>
                        <input type="file" name="myfile[]" id="myfile" multiple class="btn btn-secondary" />
                        <div class="#showPhoto">
                            <?php
                            $sql = "SELECT * FROM `product_photos` WHERE `pid` = '$key'";
                            $result = mysqli_query($link, $sql);
                            while ($row = mysqli_fetch_assoc($result)) {
                                $pid = $row["pid"];
                                $mid = $row["mid"];
                                $src = $row["src"];
                                echo "<table class='table'>";
                                echo "<tr>";
                                echo "<td>" . "<img src=$src class='img img-thumbnail' >" . "</td>";
                                echo "<td class='align-middle'>" . "<a name='' id='' class='btn btn-danger' href='./delete_Photo.php?mid=$mid&pid=$pid' role='button'>刪除</a>" . "</td>";
                                echo "</tr>";
                                echo "</table>";
                            }
                            ?>
                        </div>
                    </div>
                    <!-- 給定圖片固定大小 -->
                    <style>
                        .img-responsive {
                            max-width: 150px;
                        }

                        .img-thumbnail {
                            max-width: 100px;
                        }
                    </style>

                    <!-- Show the images preview here -->
                    <div id="upload-preview"></div>
                    <div class="form-group pt-3 d-grid gap-5 col-10 mx-auto m-3">
                        <button id="update" type="button" class="btn" style="background-color:#ff4e00;color: white" value="update">確定修改
                        </button>
                    </div>
                </form>
            </div>
            <div class="d-grid gap-5 col-6 mx-auto m-3">
                <button type="button" class="btn btn-danger col-12" data-bs-toggle="modal" data-bs-target="#staticBackdrop">刪除商品</button>
                <!-- Modal -->
                <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">提醒</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                請確認是否真的刪除商品，一但刪除即無法復原。
                            </div>
                            <div class="modal-footer">
                                <form id="delform">
                                    <input type="text" class="form-control" name="pid" aria-describedby="idhelpId" style="display: none;" value="<?= $info["pid"] ?>">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                                    <button type="button" class="btn btn-danger" id="del">確定</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

<script>
    $(document).ready(
        $("#info").validate({
            keyup: true,
            lang: 'zh_TW',
            rules: {
                pname: {
                    required: true,
                },
                category: {
                    required: true,
                },
                price: {
                    required: true,
                },
            },
            errorElement: 'div',
            errorClass: "form-text mx-2 hint_text",
            errorPlacement: function(error, element) {
                error.appendTo(element.parent())
                error.css("color", "red");
            }
        }),
        showServer($("select[name='gname'").val())
    )

    $("#update").on("click", function() {
        var form = $("#info")[0];
        var data = new FormData(form);

        var numFiles = $("#myfile")[0].files.length;

        for (var index = 0; index < numFiles; index++) {
            form.append("file", $("#myfile")[0].files[index]);
        }
        $.ajax({
            type: "POST",
            url: "./update_Product.php",
            enctype: "multipart/form-data",
            processData: false,
            cache: false,
            contentType: false,
            data: data,
            dataType: "JSON",
            success: function(response) {
                if (response["status"] == 1) {
                    alert(response["msg"]);
                    window.location.href = "./seller.php"
                } else {
                    alert(response["msg"] + "error");
                    // window.location.reload(true);
                }
            }
        });
    })

    $("#del").on("click", function() {
        $.ajax({
            type: "POST",
            url: "./delete_Product.php",
            dataType: "JSON",
            data: $("#delform").serialize(),
            success: function(response) {
                if (response["status"] == 1) {
                    alert(response["msg"]);
                    window.location.href = "./seller.php";
                } else {
                    alert(response["msg"]);
                    window.location.reload(true);
                }
            }
        });
    });

    $("select[name='gname'").change(function() {
        var gname = $(this).val();
        showServer(gname);
    })

    function showServer(gname) {
        if (gname) {
            $.ajax({
                type: "POST",
                url: "./fetch_server.php",
                data: {
                    "gname": gname,
                },
                dataType: "JSON",
                success: function(response) {
                    $("select[name='server']").empty();
                    $.each(response, function(key, value) {
                        if (key == <?= $serverid ?>) {
                            $("select[name='server']").append("<option selected value=" + key + ">" + value + "</option>");
                        } else {
                            $("select[name='server']").append("<option value=" + key + ">" + value + "</option>");
                        }
                    })
                }
            });
        } else {
            $("select[name='server']").empty();
        }
    }

    // for images
    $(function() {

        /* Check File API compatibility */
        if (!$.fileReader()) {
            alert("File API is not supported on your browser");
        } else {
            console.log("File API is supported on your browser");
        }

        /* createImage Event */
        $(document).on("createImage", function(e) {
            console.log(e.file.name);
            console.log(e.file.size);
            console.log(e.file.type);
        });

        /* deleteImage Event */
        $(document).on("deleteImage", function(e) {
            console.log(e.file.name);
            console.log(e.file.size);
            console.log(e.file.type);
            /* if not there are images, the button is disabled */
            if ($("#upload-preview").countImages() == 0) {
                $("#btn").attr("disabled", "disabled");
            }
        });

        /* Prevent form submit */
        $("#info").on("submit", function(e) {
            e.preventDefault();
        });

        /* Preview and Validate */
        $("#info input[type='file']").on("change", function() {

            $("#upload-preview").uploadImagesPreview("#info", {
                image_type: "jpg|jpeg|png|gif",
                min_size: 24,
                max_size: (1024 * 1024 * 3),
                /* 3 Mb */
                max_files: 10
            }, function() {
                switch (__errors__upload__) /* Check the possibles erros */ {
                    case 'ERROR_CONTENT_TYPE':
                        alert("Error content type");
                        break;
                    case 'ERROR_MIN_SIZE':
                        alert("Error min size");
                        break;
                    case 'ERROR_MAX_SIZE':
                        alert("Error max size");
                        break;
                    case 'ERROR_MAX_FILES':
                        alert("Error max files");
                        break;
                    default:
                        $("#btn").removeAttr("disabled");
                        break; /* Activate the button Form */
                }
            });
        });

        /* Send form */
        $("#btn").on("click", function() {

            /*images are required */
            if ($("#upload-preview").countImages() > 0) {
                $("#upload-preview").uploadImagesAjax("ajax.php", {
                    params: {
                        project_name: $("#project_name").val()
                    },
                    /* Set the extra parameters here */
                    beforeSend: function() {
                        console.log("Sending ...");
                    },
                    success: function(data) {
                        $("#upload-preview").html(data);
                        $("#info").fadeOut();
                    },
                    error: function(e) {
                        console.log(e.status);
                        console.log(e.statusText);
                    },
                    complete: function() {
                        console.log("Completed");
                    }
                });
            } else { // The button is not activated
                $(this).attr("disabled", "disabled");
            }
        });
    });
</script>