<?php

include("./config.php");

$mail = $_POST['mail'];
$sql_check_mail = "SELECT * FROM `users` WHERE `mail` = '$mail'";

if ($_POST) {
    $result = mysqli_query($link, $sql_check_mail);
    $nums = mysqli_num_rows($result);
    if ($nums > 0) {
        echo 1;
    }
    if ($nums == 0) {
        echo 0;
    }
}
