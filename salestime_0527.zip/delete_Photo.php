<?php
include("./check_session.php");
include("./config.php");

if ($_GET) {
    $mid = $_GET["mid"];
    $pid = $_GET["pid"];
    $sql = "DELETE FROM `product_photos` WHERE `mid`='$mid'";

    $result = mysqli_query($link, $sql);
    if ($result) {
        header("location: ./self_Product.php?key=$pid");
    } else {
        header("location: ./self_Product.php?key=$pid");
    }
}
