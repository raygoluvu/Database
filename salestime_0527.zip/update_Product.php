<?php
include("./check_session.php");
include("./config.php");

if ($_POST) {
    $pid = $_POST["pid"];
    $pname = $_POST["pname"];
    $price = $_POST["price"];
    $pdescribe = $_POST["pdescribe"];
    $stock = $_POST["stock"];
    $server = $_POST["server"];


    $response = array("status", "msg");
    $success_msg = "更新成功！";
    $failed_msg = "更新失敗，請再次嘗試";


    $sql = "UPDATE `products` SET `pname`='$pname', `price`='$price',`pdescribe`='$pdescribe',`stock`='$stock', `serverid`='$server' WHERE `pid` = '$pid'";
    $result = mysqli_query($link, $sql);
    if (mysqli_affected_rows($link) > 0) {
        $response["status"] = 1;
        $response["msg"] = $success_msg;

        //check if upload files
        if (isset($_FILES['myfile']['name'])) {
            $file_count = count($_FILES["myfile"]["name"]); // 照片數量
            for ($i = 0; $i < $file_count; $i++) {
                // for each file;
                $file_name = $_FILES['myfile']['name'][$i];
                $file_tmp = $_FILES['myfile']['tmp_name'][$i];
                $file_size = $_FILES['myfile']['size'][$i];
                $file_error = $_FILES['myfile']['error'][$i];

                if ($file_error === 0) {
                    $file_ext = explode('.', $file_name);
                    $name = $file_ext[0];
                    $ext = strtolower(end($file_ext)); // end(), equal to array[i];
                    $allowed = array("jpg", "png");
                    if (in_array($ext, $allowed)) {     //確認格式是否正確
                        if ($file_size < 200000) {      //或是用getimagesize();
                            $file_destination = "./img/test/" . $name . "_" . $pid . "." . $ext;
                            if (move_uploaded_file($file_tmp, $file_destination)) {
                                $sql = "INSERT INTO `product_photos`(`src`, `pid`) VALUES ('$file_destination', '$pid');";
                                $result = mysqli_query($link, $sql);
                                if ($result) {
                                    $response["msg"] = "新增商品、照片成功";
                                } else {
                                    $response["msg"] = "上傳資料庫失敗";
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        $response["status"] = 0;
        $response["msg"] = $failed_msg;
    }
    echo json_encode($response);
}
