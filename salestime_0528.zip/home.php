<!DOCTYPE html>
<?php
session_start();
include("config.php");
?>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@300&display=swap" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script type="text/javascript" src="./js/jquery.validate.js"></script>
  <script type="text/javascript" src="./js/messages_zh_TW.js"></script>
  <script type="text/javascript" src="./js/additional-methods.js"></script>
  <script src="https://kit.fontawesome.com/10094612fa.js"></script>
  <title>小賣時光－最懂你／妳的寶物交易網</title>
</head>

<style>
  header {
    background-color: #E0EDC5;
  }
</style>

<body>
  <header>
    <div class="container">
      <div id="" class="row justify-content-end">
        <div class="col-auto align-self-end">
          <a href="userlove.php">
            <i class="fa-solid fa-heart icon_head"></i>
          </a>
          <a href="warecar.php">
            <i class="fa-solid fa-cart-shopping icon_head"></i>
          </a>
          <a href="#">
            <i class="fa-solid fa-comment-dots icon_head"></i>
          </a>
          <a href="member.php">
            <i class="fa-solid fa-user icon_head" id="showID"></i>
          </a>
          <a id="logout" href="./logout.php"><i class="fa fa-sign-out"></i></a>
        </div>
      </div>
      <a class="navbar-brand" href="home.php">
        <img id="logo" src="img/logo_4.png">
      </a>

      <div class="row">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <!-- 搜尋 -->
            <!-- 這邊有改 -->
            <form action="./index.php" method="POST" id="search">
              <div class="collapse navbar-collapse col-auto" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page">
                      <div>
                        <select name="gname" id="gname" class="form-select text-left">
                          <option>選擇遊戲</option>
                          <?php
                          $sql_fetch = "SELECT * FROM `games`";
                          $f_result = mysqli_query($link, $sql_fetch);
                          $result = mysqli_query($link, "SELECT `gname` FROM `servers` WHERE `sid`='$serverid'");
                          $selName = mysqli_fetch_assoc($result)["gname"];
                          while ($row = mysqli_fetch_assoc($f_result)) {
                            $v = $row['gname'];
                            if ($selName == $v) {
                              echo "<option selected " . "value='$v'>";
                              echo $v;
                              echo "</option>";
                            } else {
                              echo "<option " . "value='$v'>";
                              echo $v;
                              echo "</option>";
                            }
                          }
                          ?>
                        </select>
                      </div>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link">
                      <select class="form-select text-left" name="server" id="server">
                        <option>選擇伺服器</option>

                      </select>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link">
                      <input id="search_width" class="search-txt text-left" type="text" name="item" placeholder="請輸入道具名稱">
                    </a>
                  </li>
                  <li class="nav-item">
                    <button disabled id="submit" name=" submit" type="submit" class="btn btn-primary">搜尋</button>
                  </li>
                </ul>
              </div>
            </form>
          </div>
        </nav>
      </div>
    </div>

  </header>

  <section id="first">
    <div class="container">
      <div class="row container-fluid justify-content-center">
        <div class="col-md">
          <div id="ad" class="text-center">
            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src="img/logo_3.png" class="d-block" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="img/logo_3.png" class="d-block" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="img/logo_3.png" class="d-block" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="img/logo_3.png" class="d-block" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="img/logo_3.png" class="d-block" alt="...">
                </div>
              </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>
          </div>
        </div>
        <!--  -->
      </div>
    </div>
  </section>

  <hr>

  <section id="second">
    <div class="container">
      <div class="row">
        <div id="game_2" class="col-md-12 text-center">
          <ul class="pagination">
            <li class="page-item ">
              <a class="page-link red" href="#">
                <h3>線上遊戲</h3>
              </a>
            </li>
            <li class="page-item">
              <a class="page-link" href="#">
                <h3>手機遊戲</h3>
              </a>
            </li>
            <li class="page-item">
              <a class="page-link" href="#">
                <h3>網頁遊戲</h3>
              </a>
            </li>
            <li class="page-item">
              <a class="page-link" href="#">
                <h3>Steam區</h3>
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div class="row">
        <div id="new" class="col-md-12 text-center">
          <ul class="pagination">
            <li class="page-item ">
              <a class=" page-link blue" href="#">
                <h3>熱門商品</h3>
              </a>
            </li>
            <li class="page-item">
              <a class="page-link" href="#">
                <h3>最新發布</h3>
              </a>
            </li>
            <li class="page-item">
              <a class="page-link" href="#">
                <h3>其他人在看</h3>
              </a>
            </li>
          </ul>
        </div>
      </div>

      <!-- 這邊也有改 -->
      <div class="row p-5">
        <h2 class="font-weight-bold mb-2">最新上架</h2>
        <div class='row pb-5 mb-4'>
          <?php
          $sql = "SELECT * FROM `products` ORDER BY `uploadtime` DESC LIMIT 10;";
          $result = mysqli_query($link, $sql);
          while ($row = mysqli_fetch_assoc($result)) {
            $pid = $row["pid"];
            $pname  = $row['pname'];
            $desc = $row['pdescribe'];
            $stock = $row['stock'];
            $sql_photo = "SELECT `src` FROM `product_photos` WHERE `pid` = '$pid'";
            $fetch = mysqli_query($link, $sql_photo);
            $src = mysqli_fetch_assoc($fetch)["src"];
            echo "<div class='col-lg-2 col-md-4 mt-2'>
            <!-- Card-->
            <div class='card rounded shadow-sm border-0'>
              <div class='card-body b-5'><img src='$src' alt='' class='img-fluid d-block mx-auto mb-3'>
                <h5> <a href='./waredetail.php?pid=$pid' class='text-dark'>$pname</a></h5>
                <p class='small text-muted font-italic'>$desc</p>
                <span>剩餘:$stock</span>
              </div>
            </div>
          </div>";
          }
          ?>
        </div>


  </section>

  <section id="third">
    <div class="row container-fluid">
      <div id="title" class="col-md-12 text-center">
        <img src="img/logo_1.png">
      </div>
    </div>
  </section>

  <footer id="foot-one">
    <div class="container">
      <div class="row">
        <div class="col-md-3 text-center">
          <h5 class="fw-bold">新手上路</h5>
          <p><a href="#">免費註冊</a></p>
          <p><a href="#">交易流程</a></p>
          <p><a href="#">付款方式</a></p>
        </div>
        <div class="col-md-3 text-center">
          <h5 class="fw-bold">售後服務</h5>
          <p><a href="#">交易申訴</a></p>
          <p><a href="#">申請取消交易</a></p>
          <p><a href="#">提款相關</a></p>
        </div>
        <div class="col-md-3 text-center">
          <h5 class="fw-bold">客戶服務</h5>
          <p>客服電話：(02) 5579-8591</p>
          <p>服務時間：週一至週五10:00-21:00</p>
          <p>例行維護：每日4:30-5:00</p>
        </div>
        <div class="col-md-3 text-center">
          <h5 class="fw-bold">常用入口</h5>
          <p><a href="#">帳號切結書下載</a></p>
          <p><a href="#">留言諮詢</a></p>
          <p><a href="#">客服信箱</a></p>
        </div>
      </div>
    </div>
  </footer>

  <button type="button" class="btn btn-danger btn-floating btn-lg back-to-top" id="btn-back-to-top">
    <i class="fa-solid fa-arrow-up"></i>
  </button>

  <!-- <script src="js/test.js"></script> -->
</body>

</html>

<script>
  $(document).ready(
    function() {
      $.ajax({
        url: "./getUser.php",
        type: "POST",
        dataType: "JSON",
        success: function(response) {
          $("#showID").append(response["msg"]);
        }
      })
    },

    $("#logout").click(function() {
      alert("帳號已登出");
      window.location.href = "./home.php";
    }),

    // 這裡應該也有改
    $("select[name='gname'").change(function() {
      var gname = $(this).val();
      console.log(gname);

      if ((gname)) {
        $.ajax({
          type: "POST",
          url: "./fetch_server.php",
          data: {
            "gname": gname,
          },
          dataType: "JSON",
          success: function(response) {
            $("select[name='server']").empty();
            $("select[name='server']").append("<option selected>" + "請選擇伺服器" + "</option>");
            $.each(response, function(key, value) {
              $("select[name='server']").append("<option value=" + key + ">" + value + "</option>");
            })
          }
        });
      } else {
        $("select[name='server']").empty();
      }
    }),
    $("select[name='server']").change(function() {
      $("#submit").removeAttr("disabled")
    })
  )
</script>