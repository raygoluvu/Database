<?php
include("./config.php");
include("./check_session.php");
if ($_POST) {
    $pname = $_POST["pname"];
    $price = $_POST["price"];
    $pdescribe = $_POST["pdescribe"];
    $stock = $_POST["stock"];
    $server = $_POST["server"];

    $response = array("status", "msg");
    $success_msg = "新增成功！";
    $failed_msg = "新增失敗，請再次嘗試";


    $sql = "INSERT INTO `products`(`pname`, `price`, `pdescribe`, `sid`, `stock`, `serverid`) VALUES ('$pname', '$price', '$pdescribe', '$acc' ,'$stock', '$server')";

    $result = mysqli_query($link, $sql);
    if (mysqli_affected_rows($link) > 0) {
        $response["status"] = 1;
        $response["msg"] = $success_msg;

        $sql = "SELECT * FROM `PRODUCTS` ORDER BY uploadtime DESC limit 1;";
        $latest = mysqli_query($link, $sql);
        $pid = mysqli_fetch_assoc($latest)["pid"];

        //check if upload files
        if (isset($_FILES['myfile']['name'])) {
            $file_count = count($_FILES["myfile"]["name"]); // 照片數量
            for ($i = 0; $i < $file_count; $i++) {
                // for each file;
                $file_name = $_FILES['myfile']['name'][$i];
                $file_tmp = $_FILES['myfile']['tmp_name'][$i];
                $file_size = $_FILES['myfile']['size'][$i];
                $file_error = $_FILES['myfile']['error'][$i];

                if ($file_error === 0) {
                    $file_ext = explode('.', $file_name);
                    $name = $file_ext[0];
                    $ext = strtolower(end($file_ext)); // end(), equal to array[i];
                    $allowed = array("jpg", "png");
                    if (in_array($ext, $allowed)) {     //確認格式是否正確
                        if ($file_size < 200000) {      //或是用getimagesize();
                            $file_destination = "./img/test/" . $name . "_" . $pid . "." . $ext;
                            if (move_uploaded_file($file_tmp, $file_destination)) {
                                $sql = "INSERT INTO `product_photos`(`src`, `pid`) VALUES ('$file_destination', '$pid');";
                                $result = mysqli_query($link, $sql);
                                if ($result) {
                                    $response["msg"] = "新增商品、照片成功";
                                } else {
                                    $response["msg"] = "上傳資料庫失敗";
                                }
                            }
                        }
                    }
                }
            }
        }
        if (empty($_FILES)) {
            // 沒起作用
            $sql = "INSERT INTO `product_photos`(`src`, `pid`) VALUES ('./img/default_img.jpg', '$pid');";
            $result = mysqli_query($link, $sql);
            if ($result) {
                $response["msg"] = "新增商品成功，但未上傳相片";
            } else {
                $response["msg"] = "sql error";
            }
        }
    } else {
        $response["status"] = 0;
        $response["msg"] = $failed_msg;
    }
    echo json_encode($response);
}
