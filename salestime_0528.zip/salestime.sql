-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 28, 2022 at 10:30 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `salestime`
--

-- --------------------------------------------------------

--
-- Table structure for table `authorization`
--

CREATE TABLE `authorization` (
  `id` varchar(11) NOT NULL,
  `token` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `authorization`
--

INSERT INTO `authorization` (`id`, `token`) VALUES
('a', '0cc175b9c0f1b6a831c399e2697726610cc175b9c0f1b6a831c399e269772661'),
('b', '92eb5ffee6ae2fec3ad71c777531578f92eb5ffee6ae2fec3ad71c777531578f');

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

CREATE TABLE `games` (
  `gname` varchar(10) NOT NULL,
  `gtype` varchar(10) NOT NULL DEFAULT '其他'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `games`
--

INSERT INTO `games` (`gname`, `gtype`) VALUES
('APEX', '線上遊戲'),
('GTA V', '線上遊戲'),
('VALORANT', '線上遊戲'),
('原神', '手機遊戲'),
('楓之谷', '線上遊戲'),
('賽爾號', '網頁遊戲');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pname` varchar(10) NOT NULL,
  `price` int(10) NOT NULL DEFAULT 999999,
  `pid` int(5) NOT NULL,
  `pdescribe` varchar(200) NOT NULL,
  `sid` varchar(10) NOT NULL,
  `uploadtime` timestamp NOT NULL DEFAULT current_timestamp(),
  `stock` int(5) NOT NULL DEFAULT 1,
  `serverid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pname`, `price`, `pid`, `pdescribe`, `sid`, `uploadtime`, `stock`, `serverid`) VALUES
('商品測試', 100, 66, '無', 'a', '2022-05-28 05:33:53', 100, 3),
('商品測試', 100, 67, '無', 'a', '2022-05-28 05:33:53', 100, 3),
('商品測試', 100, 68, '無', 'a', '2022-05-28 05:33:53', 100, 3),
('商品測試', 100, 69, '無', 'a', '2022-05-28 05:33:53', 100, 3),
('商品測試', 100, 70, '無', 'a', '2022-05-28 05:33:53', 100, 3),
('商品測試', 100, 71, '無', 'a', '2022-05-28 05:33:53', 100, 3),
('商品測試', 100, 72, '無', 'a', '2022-05-28 05:33:53', 100, 3),
('商品測試', 100, 73, '無', 'a', '2022-05-28 05:33:53', 100, 3);

-- --------------------------------------------------------

--
-- Table structure for table `product_photos`
--

CREATE TABLE `product_photos` (
  `mid` int(11) NOT NULL,
  `src` varchar(50) NOT NULL,
  `pid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_photos`
--

INSERT INTO `product_photos` (`mid`, `src`, `pid`) VALUES
(24, './img/test/logo_1_39.png', 39),
(25, './img/test/logo_3_40.png', 40),
(26, './img/test/logo_41.png', 41),
(27, './img/test/logo_1_42.png', 42),
(28, './img/test/logo_50.png', 50),
(29, './img/test/logo_1_50.png', 50),
(30, './img/test/logo_2_50.png', 50),
(31, './img/test/logo_51.png', 51),
(32, './img/test/logo_1_51.png', 51),
(33, './img/test/logo_2_51.png', 51),
(34, './img/test/logo_52.png', 52),
(35, './img/test/logo_1_52.png', 52),
(36, './img/test/logo_2_52.png', 52),
(37, './img/test/logo_53.png', 53),
(38, './img/test/logo_1_53.png', 53),
(39, './img/test/logo_2_53.png', 53),
(40, './img/test/logo_3_53.png', 53),
(41, './img/test/logo_4_53.png', 53),
(42, './img/test/a66277d0-81b9-460a-8728-1d15ce33254d_54', 54),
(43, './img/test/images_54.png', 54),
(44, './img/test/sign-out-alt_55.png', 55),
(45, './img/test/user-free-icon-font_60.png', 60),
(51, './img/test/discount_64.png', 64),
(52, './img/test/brainstorm_64.png', 64),
(53, './img/test/data-wave_64.png', 64),
(57, './img/test/logo_4_65.png', 65),
(58, './img/test/sleep_66.png', 66),
(60, './img/test/sync_67.png', 67),
(63, './img/test/discount_68.png', 68),
(64, './img/test/100_69.png', 69),
(65, './img/test/dream_70.png', 70),
(66, './img/test/tired-free-icon-font_71.png', 71),
(67, './img/test/globe-free-icon-font_72.png', 72),
(68, './img/test/speak_73.png', 73),
(69, './img/default_img.jpg', 74),
(70, './img/test/speak_66.png', 66),
(71, './img/test/dream_66.png', 66);

-- --------------------------------------------------------

--
-- Table structure for table `servers`
--

CREATE TABLE `servers` (
  `sid` int(11) NOT NULL,
  `gname` varchar(10) NOT NULL,
  `sname` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `servers`
--

INSERT INTO `servers` (`sid`, `gname`, `sname`) VALUES
(1, 'APEX', '台灣'),
(3, 'APEX', '香港'),
(4, 'APEX', '日本'),
(5, 'GTA V', '香港'),
(6, '賽爾號', '台灣'),
(7, 'APEX', '美洲'),
(8, 'GTA V', '台灣'),
(9, 'GTA V', '日本'),
(10, 'VALORANT', '台灣'),
(11, 'VALORANT', '日本'),
(12, 'VALORANT', '香港'),
(13, '原神', '台灣'),
(14, '原神', '日本'),
(15, '原神', '香港'),
(16, '楓之谷', '台灣'),
(17, '楓之谷', '日本'),
(18, '楓之谷', '香港'),
(19, '賽爾號', '日本'),
(20, '賽爾號', '香港');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `account` varchar(10) NOT NULL,
  `password` varchar(15) NOT NULL,
  `username` varchar(10) NOT NULL,
  `name` varchar(10) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `mail` varchar(30) NOT NULL,
  `id` varchar(10) NOT NULL,
  `status` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`account`, `password`, `username`, `name`, `phone`, `mail`, `id`, `status`) VALUES
('a', '12345678', 'admin1', 'admin', '0987654321', 'hp97001@gmail.com', 'a', 1),
('b', 'b', 'b', 'b', 'b', 'onlyfordb2022@gmail.com', 'b', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authorization`
--
ALTER TABLE `authorization`
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`gname`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `sid` (`sid`);

--
-- Indexes for table `product_photos`
--
ALTER TABLE `product_photos`
  ADD PRIMARY KEY (`mid`),
  ADD UNIQUE KEY `src` (`src`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `servers`
--
ALTER TABLE `servers`
  ADD PRIMARY KEY (`sid`),
  ADD KEY `gname` (`gname`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`account`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `mail` (`mail`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `pid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `product_photos`
--
ALTER TABLE `product_photos`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `servers`
--
ALTER TABLE `servers`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
