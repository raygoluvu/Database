<?php

session_start();

if (isset($_SESSION["loggedin"]) && isset($_SESSION["acc"]) && !empty($_SESSION["acc"])) {
    $acc = $_SESSION["acc"];
    $sql = "SELECT `status` FROM `users`WHERE `account`='$acc'";
    $result = mysqli_query($link, $sql);
    if (!$status = mysqli_fetch_assoc($result)["status"]) {
        echo "<script>";
        echo "alert('請前往郵件開通帳號，若資料有誤請至會員中心修改')";
        echo "</script>";
    }
} else {
    header("Location: ./home.php");
    exit;
}
