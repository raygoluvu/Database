<?php
include("./config.php");

$acc = $_POST['acc'];
$sql_check_acc = "SELECT * FROM `users` WHERE `account` = '$acc'";
$uname  = $_POST['username'];
$sql_check_n = "SELECT * FROM `users` WHERE `username` = '$uname'";

$ret_arr =  array();

if ($_POST) {
    $num1 = mysqli_num_rows(mysqli_query($link, $sql_check_acc));
    $num2 = mysqli_num_rows(mysqli_query($link, $sql_check_n));
    $num3 = $_POST['pwd'] != $_POST['pwd_check'];
    if ($num1 or $num2 or $num3) {
        $status = 0;
        $text = "輸入資料有誤";
    } else {
        $status = 1;
        $text = "請繼續填寫個人資料";
    }
    $ret_arr[] = array("status" => $status, "text" => $text);
    echo json_encode($ret_arr);
}
