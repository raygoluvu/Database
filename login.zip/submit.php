<?php
include("./config.php");


$acc = $_POST['acc'];
$pwd = $_POST['pwd'];
$un = $_POST['username'];
$name = $_POST['realname'];
$phone = $_POST['phone'];
$mail = $_POST['mail'];
$pid = $_POST['pid'];

if ($_POST) {
    $sql = "INSERT INTO `users`(`account`, `password`, `username`, `name`, `phone`, `mail`, `id`)VALUES ('$acc','$pwd','$un','$name','$phone','$mail','$pid')";
    $result = mysqli_query($link, $sql);

    if ($result) {
        $ret = "成功新增帳號，請重新登入";
    } else {
        $ret = "建立帳號失敗，請重新嘗試";
    }
    echo json_encode($arr[] = array("text" => $ret));
}
